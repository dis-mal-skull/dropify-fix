<?php

global $states;

$states['CL'] = array (
	'AP' => 'ARICA Y PARINACOTA',
	'TA' => 'TARAPACÁ',
	'AN' => 'ANTOFAGASTA',
	'AT' => 'ATACAMA',
	'CO' => 'COQUIMBO',
	'VS' => 'VALPARAISO',
	'RM' => 'METROPOLITANA DE SANTIAGO',
	'LI' => "LIBERTADOR GENERAL BERNARDO O'HIGGINS",
	'ML' => 'MAULE',
	'NB' => 'ÑUBLE',
	'BI' => 'BÍO BÍO',
    'AR' => 'ARAUCANÍA',
    'LR' => 'LOS RÍOS',
    'LL' => 'LOS LAGOS',
    'AI' => 'AYSÉN',
    'MA' => 'MAGALLANES Y LA ANTARTICA CHILENA',
	
	);