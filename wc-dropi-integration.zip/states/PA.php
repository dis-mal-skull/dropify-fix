<?php
/**
 * Colombia states
 *
 * @author   Saul Morales Pacheco <moralespachecopablo@gmail.com>
 * @version  1.1.33
 * @license http://opensource.org/licenses/gpl-license.php GNU Public License
 */

global $states;

$states ['PA' ] = array (
	'PA-1' => 'BOCAS DEL TORO',
	'PA-4' => 'CHIRIQUI',
	'PA-2' => 'COCLE',
	'PA-3' => 'COLON',
	'PA-EM' => 'COMARCA EMBERA',
	'PA-5' => 'DARIEN',
	'PA-6' => 'HERRERA',
	'PA-7' => 'LOS SANTOS',
	'PA-8' => 'PANAMA',
	'PA-9' => 'VERAGUA',
	'PA-10' => 'PANAMA OESTE',
	
	);