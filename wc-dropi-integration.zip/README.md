## SVN 

$ svn cp trunk tags/4.4
$ svn ci -m "tagging version 4.4"